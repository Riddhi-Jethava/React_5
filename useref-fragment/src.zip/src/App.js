import './App.css';
import Refer from './Refer';

function App() {
  return (
    <>
      <Refer/>
    </>
  );
}

export default App;
