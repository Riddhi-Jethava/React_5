import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import './App.css';
import FormStyling from './FormStyling';

function App() {
  return (
    <div className="App">
      <FormStyling/>
    </div>
  );
}

export default App;
