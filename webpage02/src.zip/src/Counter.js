import React from 'react'

function Counter() {
  return (
    <div className='container-fliud counter'>
      <div className='row m-0 text-white'>
          
      </div>
    </div>
  )
}


export default Counter
